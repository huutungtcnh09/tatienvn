ALTER TABLE `sales_order`
  ADD COLUMN `applied_from_balance` DECIMAL(18,2) NOT NULL DEFAULT 0 AFTER `paid_amount`;
