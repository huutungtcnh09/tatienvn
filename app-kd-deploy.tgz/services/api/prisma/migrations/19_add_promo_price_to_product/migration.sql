-- Add promo_price column to product table (replaces dropped special_price)
ALTER TABLE `product`
  ADD COLUMN `promo_price` DECIMAL(18,2) NULL;

-- Restore any data from backup if available (none expected since special_price was sparse)
