CREATE TABLE `corporate_consultation` (
  `id`           VARCHAR(191) NOT NULL,
  `product_id`   VARCHAR(191) NOT NULL,
  `product_name` VARCHAR(191) NOT NULL,
  `full_name`    VARCHAR(191) NOT NULL,
  `phone`        VARCHAR(191) NOT NULL,
  `email`        VARCHAR(191) NULL,
  `company`      VARCHAR(191) NULL,
  `note`         TEXT         NULL,
  `source_path`  VARCHAR(191) NULL,
  `status`       ENUM('NEW','CONTACTED','QUOTED','CLOSED','SPAM') NOT NULL DEFAULT 'NEW',
  `staff_note`   TEXT         NULL,
  `assigned_to`  VARCHAR(191) NULL,
  `submitted_at` DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at`   DATETIME(3)  NOT NULL,

  INDEX `corporate_consultation_status_idx`(`status`),
  INDEX `corporate_consultation_submitted_at_idx`(`submitted_at`),
  INDEX `corporate_consultation_phone_idx`(`phone`),

  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
