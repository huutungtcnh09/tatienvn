CREATE TABLE `sales_order_return` (
  `id` VARCHAR(191) NOT NULL,
  `order_id` VARCHAR(191) NOT NULL,
  `type` VARCHAR(50) NOT NULL,
  `amount` DECIMAL(18,2) NOT NULL,
  `note` TEXT NULL,
  `restock` BOOLEAN NOT NULL DEFAULT true,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  INDEX `sales_order_return_order_id_idx`(`order_id`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE `sales_order_return_item` (
  `id` VARCHAR(191) NOT NULL,
  `return_id` VARCHAR(191) NOT NULL,
  `order_item_id` VARCHAR(191) NOT NULL,
  `quantity` INT NOT NULL,
  `amount` DECIMAL(18,2) NOT NULL,

  INDEX `sales_order_return_item_return_id_idx`(`return_id`),
  INDEX `sales_order_return_item_order_item_id_idx`(`order_item_id`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `sales_order_return`
  ADD CONSTRAINT `sales_order_return_order_id_fkey`
    FOREIGN KEY (`order_id`) REFERENCES `sales_order`(`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE `sales_order_return_item`
  ADD CONSTRAINT `sales_order_return_item_return_id_fkey`
    FOREIGN KEY (`return_id`) REFERENCES `sales_order_return`(`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `sales_order_return_item_order_item_id_fkey`
    FOREIGN KEY (`order_item_id`) REFERENCES `sales_order_item`(`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;
