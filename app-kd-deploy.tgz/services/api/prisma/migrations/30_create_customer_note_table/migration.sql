CREATE TABLE `customer_note` (
  `id` VARCHAR(191) NOT NULL,
  `customer_id` VARCHAR(191) NOT NULL,
  `created_by_user_id` VARCHAR(191) NULL,
  `content` LONGTEXT NOT NULL,
  `is_starred` BOOLEAN NOT NULL DEFAULT false,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` DATETIME(3) NOT NULL,

  INDEX `customer_note_customer_id_created_at_idx`(`customer_id`, `created_at`),
  INDEX `customer_note_created_by_user_id_created_at_idx`(`created_by_user_id`, `created_at`),
  INDEX `customer_note_customer_id_is_starred_created_at_idx`(`customer_id`, `is_starred`, `created_at`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `customer_note`
  ADD CONSTRAINT `customer_note_customer_id_fkey`
  FOREIGN KEY (`customer_id`) REFERENCES `partner`(`id`)
  ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE `customer_note`
  ADD CONSTRAINT `customer_note_created_by_user_id_fkey`
  FOREIGN KEY (`created_by_user_id`) REFERENCES `user`(`id`)
  ON DELETE SET NULL ON UPDATE CASCADE;
