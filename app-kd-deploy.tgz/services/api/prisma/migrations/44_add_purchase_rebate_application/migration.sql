CREATE TABLE purchase_rebate_application (
  id VARCHAR(191) NOT NULL PRIMARY KEY,
  purchase_rebate_id VARCHAR(191) NOT NULL,
  purchase_order_id VARCHAR(191) NOT NULL,
  allocated_amount DECIMAL(18,2) NOT NULL,
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  CONSTRAINT purchase_rebate_application_rebate_fk FOREIGN KEY (purchase_rebate_id) REFERENCES purchase_rebate(id) ON DELETE CASCADE,
  CONSTRAINT purchase_rebate_application_po_fk FOREIGN KEY (purchase_order_id) REFERENCES purchase_order(id) ON DELETE CASCADE,
  UNIQUE KEY purchase_rebate_application_rebate_po_uk (purchase_rebate_id, purchase_order_id),
  KEY purchase_rebate_application_po_idx (purchase_order_id),
  KEY purchase_rebate_application_rebate_idx (purchase_rebate_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
