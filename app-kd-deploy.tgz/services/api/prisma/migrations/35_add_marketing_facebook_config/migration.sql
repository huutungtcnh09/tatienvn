CREATE TABLE IF NOT EXISTS `marketing_facebook_config` (
  `id` VARCHAR(191) NOT NULL,
  `app_id` VARCHAR(191) NULL,
  `app_secret` TEXT NULL,
  `access_token` TEXT NULL,
  `ad_account_id` VARCHAR(191) NULL,
  `updated_at` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
