ALTER TABLE sales_order
  DROP COLUMN is_prepaid;
