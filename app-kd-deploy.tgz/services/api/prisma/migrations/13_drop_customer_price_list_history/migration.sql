-- Drop customer_price_list_history table
DROP TABLE IF EXISTS `customer_price_list_history`;
