ALTER TABLE `partner`
  ADD COLUMN `customer_price_tier` VARCHAR(32) NULL;

ALTER TABLE `product`
  ADD COLUMN `level_2_price` DECIMAL(18,2) NOT NULL DEFAULT 0,
  ADD COLUMN `level_2_special_price` DECIMAL(18,2) NOT NULL DEFAULT 0;

UPDATE `product`
SET
  `level_2_price` = `default_price`,
  `level_2_special_price` = `default_price`
WHERE `level_2_price` = 0 AND `level_2_special_price` = 0;
