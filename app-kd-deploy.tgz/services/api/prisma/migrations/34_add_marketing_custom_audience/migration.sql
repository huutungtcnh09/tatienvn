-- Add extra customer phones for custom audience matching.
SET @has_phone_2 := (
  SELECT COUNT(*)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'partner'
    AND COLUMN_NAME = 'phone_2'
);

SET @add_phone_2_sql := IF(
  @has_phone_2 = 0,
  'ALTER TABLE `partner` ADD COLUMN `phone_2` VARCHAR(191) NULL AFTER `phone`',
  'SELECT 1'
);
PREPARE stmt_add_phone_2 FROM @add_phone_2_sql;
EXECUTE stmt_add_phone_2;
DEALLOCATE PREPARE stmt_add_phone_2;

SET @has_phone_3 := (
  SELECT COUNT(*)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'partner'
    AND COLUMN_NAME = 'phone_3'
);

SET @add_phone_3_sql := IF(
  @has_phone_3 = 0,
  'ALTER TABLE `partner` ADD COLUMN `phone_3` VARCHAR(191) NULL AFTER `phone_2`',
  'SELECT 1'
);
PREPARE stmt_add_phone_3 FROM @add_phone_3_sql;
EXECUTE stmt_add_phone_3;
DEALLOCATE PREPARE stmt_add_phone_3;

CREATE TABLE IF NOT EXISTS `marketing_custom_audience` (
  `id` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `description` TEXT NULL,
  `facebook_audience_id` VARCHAR(191) NULL,
  `ad_account_id` VARCHAR(191) NULL,
  `created_by_user_id` VARCHAR(191) NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` DATETIME(3) NOT NULL,
  INDEX `marketing_custom_audience_facebook_audience_id_idx` (`facebook_audience_id`),
  INDEX `marketing_custom_audience_created_by_user_id_idx` (`created_by_user_id`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `marketing_custom_audience_detail` (
  `id` VARCHAR(191) NOT NULL,
  `custom_audience_id` VARCHAR(191) NOT NULL,
  `customer_id` VARCHAR(191) NULL,
  `email` VARCHAR(191) NULL,
  `phone_1` VARCHAR(191) NULL,
  `phone_2` VARCHAR(191) NULL,
  `phone_3` VARCHAR(191) NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` DATETIME(3) NOT NULL,
  INDEX `marketing_custom_audience_detail_custom_audience_id_idx` (`custom_audience_id`),
  INDEX `marketing_custom_audience_detail_customer_id_idx` (`customer_id`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

SET @has_fk_mca_user := (
  SELECT COUNT(*)
  FROM information_schema.REFERENTIAL_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = DATABASE()
    AND TABLE_NAME = 'marketing_custom_audience'
    AND CONSTRAINT_NAME = 'marketing_custom_audience_created_by_user_id_fkey'
);

SET @add_fk_mca_user_sql := IF(
  @has_fk_mca_user = 0,
  'ALTER TABLE `marketing_custom_audience` ADD CONSTRAINT `marketing_custom_audience_created_by_user_id_fkey` FOREIGN KEY (`created_by_user_id`) REFERENCES `user`(`id`) ON DELETE SET NULL ON UPDATE CASCADE',
  'SELECT 1'
);
PREPARE stmt_add_fk_mca_user FROM @add_fk_mca_user_sql;
EXECUTE stmt_add_fk_mca_user;
DEALLOCATE PREPARE stmt_add_fk_mca_user;

SET @has_fk_mcad_audience := (
  SELECT COUNT(*)
  FROM information_schema.REFERENTIAL_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = DATABASE()
    AND TABLE_NAME = 'marketing_custom_audience_detail'
    AND CONSTRAINT_NAME = 'marketing_custom_audience_detail_custom_audience_id_fkey'
);

SET @add_fk_mcad_audience_sql := IF(
  @has_fk_mcad_audience = 0,
  'ALTER TABLE `marketing_custom_audience_detail` ADD CONSTRAINT `marketing_custom_audience_detail_custom_audience_id_fkey` FOREIGN KEY (`custom_audience_id`) REFERENCES `marketing_custom_audience`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE',
  'SELECT 1'
);
PREPARE stmt_add_fk_mcad_audience FROM @add_fk_mcad_audience_sql;
EXECUTE stmt_add_fk_mcad_audience;
DEALLOCATE PREPARE stmt_add_fk_mcad_audience;

SET @has_fk_mcad_customer := (
  SELECT COUNT(*)
  FROM information_schema.REFERENTIAL_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = DATABASE()
    AND TABLE_NAME = 'marketing_custom_audience_detail'
    AND CONSTRAINT_NAME = 'marketing_custom_audience_detail_customer_id_fkey'
);

SET @add_fk_mcad_customer_sql := IF(
  @has_fk_mcad_customer = 0,
  'ALTER TABLE `marketing_custom_audience_detail` ADD CONSTRAINT `marketing_custom_audience_detail_customer_id_fkey` FOREIGN KEY (`customer_id`) REFERENCES `partner`(`id`) ON DELETE SET NULL ON UPDATE CASCADE',
  'SELECT 1'
);
PREPARE stmt_add_fk_mcad_customer FROM @add_fk_mcad_customer_sql;
EXECUTE stmt_add_fk_mcad_customer;
DEALLOCATE PREPARE stmt_add_fk_mcad_customer;
