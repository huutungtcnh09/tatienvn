ALTER TABLE `partner_transaction_log`
  MODIFY COLUMN `transaction_type` ENUM(
    'SALE_ORDER',
    'PAYMENT_RECEIPT',
    'RECEIPT_VOID',
    'DISCOUNT_VOUCHER',
    'RETURN_ORDER',
    'PURCHASE_ORDER',
    'PURCHASE_VOID',
    'PAYMENT_TO_SUPPLIER',
    'OPENING_BALANCE',
    'SUPPLIER_REBATE'
  ) NOT NULL;

ALTER TABLE `receipt`
  ADD COLUMN `voided_by_user_id` VARCHAR(191) NULL,
  ADD COLUMN `status` ENUM('ACTIVE','VOIDED') NOT NULL DEFAULT 'ACTIVE',
  ADD COLUMN `void_reason` LONGTEXT NULL,
  ADD COLUMN `voided_at` DATETIME(3) NULL,
  ADD COLUMN `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3);

CREATE INDEX `receipt_voided_by_user_id_idx` ON `receipt`(`voided_by_user_id`);
CREATE INDEX `receipt_status_created_at_idx` ON `receipt`(`status`, `created_at`);

ALTER TABLE `receipt`
  ADD CONSTRAINT `receipt_voided_by_user_id_fkey`
  FOREIGN KEY (`voided_by_user_id`) REFERENCES `user`(`id`)
  ON DELETE SET NULL ON UPDATE CASCADE;
