ALTER TABLE `partner`
  ADD COLUMN `net_balance` DECIMAL(18,2) NOT NULL DEFAULT 0 AFTER `opening_balance`;

UPDATE `partner`
SET `net_balance` = COALESCE(`current_debt`, 0) - COALESCE(`advance_balance`, 0);

ALTER TABLE `partner`
  DROP COLUMN `current_debt`,
  DROP COLUMN `advance_balance`;
