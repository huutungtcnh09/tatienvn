-- Remove purchase expense table and landed cost columns
DROP TABLE IF EXISTS `purchase_expense`;

ALTER TABLE `purchase_order` DROP COLUMN `landed_cost`;

ALTER TABLE `purchase_order_item` DROP COLUMN `allocated_landed_cost`;
ALTER TABLE `purchase_order_item` DROP COLUMN `net_amount`;
ALTER TABLE `purchase_order_item` DROP COLUMN `unit_net_cost`;
