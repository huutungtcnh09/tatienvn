-- Create customer_watchlist table to persist per-user watched customers on the server
CREATE TABLE `customer_watchlist` (
  `id`          VARCHAR(191) NOT NULL,
  `user_id`     VARCHAR(191) NOT NULL,
  `customer_id` VARCHAR(191) NOT NULL,
  `source`      VARCHAR(191) NOT NULL DEFAULT 'debt',
  `added_at`    DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  UNIQUE INDEX `customer_watchlist_user_customer_uk` (`user_id`, `customer_id`),
  INDEX `customer_watchlist_user_id_idx` (`user_id`),

  CONSTRAINT `customer_watchlist_user_id_fk`     FOREIGN KEY (`user_id`)     REFERENCES `user`    (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `customer_watchlist_customer_id_fk` FOREIGN KEY (`customer_id`) REFERENCES `partner` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,

  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
