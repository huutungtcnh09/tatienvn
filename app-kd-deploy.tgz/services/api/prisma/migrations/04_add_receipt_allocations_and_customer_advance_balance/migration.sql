ALTER TABLE `partner`
  ADD COLUMN `advance_balance` DECIMAL(18,2) NOT NULL DEFAULT 0 AFTER `current_debt`;

CREATE TABLE `receipt_allocation` (
  `id` VARCHAR(191) NOT NULL,
  `receipt_id` VARCHAR(191) NOT NULL,
  `order_id` VARCHAR(191) NOT NULL,
  `applied_amount` DECIMAL(18,2) NOT NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  UNIQUE INDEX `receipt_allocation_receipt_id_order_id_key`(`receipt_id`, `order_id`),
  INDEX `receipt_allocation_order_id_idx`(`order_id`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `receipt_allocation`
  ADD CONSTRAINT `receipt_allocation_receipt_id_fkey`
    FOREIGN KEY (`receipt_id`) REFERENCES `receipt`(`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `receipt_allocation_order_id_fkey`
    FOREIGN KEY (`order_id`) REFERENCES `sales_order`(`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;
