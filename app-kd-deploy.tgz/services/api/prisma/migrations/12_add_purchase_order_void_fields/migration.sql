-- Migration 12: Add void fields to purchase_order table
ALTER TABLE `purchase_order`
  ADD COLUMN `voided_at`         DATETIME           NULL,
  ADD COLUMN `void_reason`       VARCHAR(500)       NULL,
  ADD COLUMN `voided_by_user_id` VARCHAR(191)       NULL;
