-- Migration 26: Remove SALES_STAFF from OrgRoleType, add CEO and CHIEF_ACCOUNTANT
-- Step 1: Expand enum to include all values (old + new) temporarily
ALTER TABLE `org_assignment_history`
  MODIFY COLUMN `role_type` ENUM(
    'SALES_STAFF','STORE_MANAGER','STORE_SUPERVISOR',
    'DEPUTY_MANAGER','CASHIER','WAREHOUSE_STAFF','PURCHASER','CUSTOMER_SERVICE',
    'CEO','CHIEF_ACCOUNTANT'
  ) NOT NULL;

ALTER TABLE `org_position`
  MODIFY COLUMN `role_type` ENUM(
    'SALES_STAFF','STORE_MANAGER','STORE_SUPERVISOR',
    'DEPUTY_MANAGER','CASHIER','WAREHOUSE_STAFF','PURCHASER','CUSTOMER_SERVICE',
    'CEO','CHIEF_ACCOUNTANT'
  ) NOT NULL;

-- Step 2: Migrate existing SALES_STAFF records to CUSTOMER_SERVICE
UPDATE `org_assignment_history` SET `role_type` = 'CUSTOMER_SERVICE' WHERE `role_type` = 'SALES_STAFF';
UPDATE `org_position` SET `role_type` = 'CUSTOMER_SERVICE' WHERE `role_type` = 'SALES_STAFF';

-- Step 3: Remove SALES_STAFF from enum (final set without it)
ALTER TABLE `org_assignment_history`
  MODIFY COLUMN `role_type` ENUM(
    'STORE_MANAGER','STORE_SUPERVISOR',
    'DEPUTY_MANAGER','CASHIER','WAREHOUSE_STAFF','PURCHASER','CUSTOMER_SERVICE',
    'CEO','CHIEF_ACCOUNTANT'
  ) NOT NULL;

ALTER TABLE `org_position`
  MODIFY COLUMN `role_type` ENUM(
    'STORE_MANAGER','STORE_SUPERVISOR',
    'DEPUTY_MANAGER','CASHIER','WAREHOUSE_STAFF','PURCHASER','CUSTOMER_SERVICE',
    'CEO','CHIEF_ACCOUNTANT'
  ) NOT NULL;
