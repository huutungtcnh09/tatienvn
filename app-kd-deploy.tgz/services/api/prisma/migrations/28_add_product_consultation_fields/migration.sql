ALTER TABLE `product`
  ADD COLUMN `ingredients` LONGTEXT NULL,
  ADD COLUMN `benefits` LONGTEXT NULL,
  ADD COLUMN `usage_guide` LONGTEXT NULL;
