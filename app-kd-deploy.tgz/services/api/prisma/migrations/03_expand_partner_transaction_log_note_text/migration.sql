ALTER TABLE `partner_transaction_log`
  MODIFY `note` TEXT NULL;