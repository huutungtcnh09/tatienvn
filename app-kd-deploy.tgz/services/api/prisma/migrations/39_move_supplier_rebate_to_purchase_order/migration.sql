ALTER TABLE `purchase_order`
  ADD COLUMN `rebate_amount` DECIMAL(18, 2) NOT NULL DEFAULT 0 AFTER `landed_cost`,
  ADD COLUMN `rebate_cogs_adjustment` DECIMAL(18, 2) NOT NULL DEFAULT 0 AFTER `rebate_amount`,
  ADD COLUMN `rebate_inventory_adjustment` DECIMAL(18, 2) NOT NULL DEFAULT 0 AFTER `rebate_cogs_adjustment`,
  ADD COLUMN `rebate_purchased_qty` INT NOT NULL DEFAULT 0 AFTER `rebate_inventory_adjustment`,
  ADD COLUMN `rebate_sold_qty` INT NOT NULL DEFAULT 0 AFTER `rebate_purchased_qty`;

DROP TABLE IF EXISTS `supplier_rebate_adjustment`;