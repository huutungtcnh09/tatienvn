-- Migration 25: Expand OrgRoleType enum with more organizational roles
ALTER TABLE `org_assignment_history`
  MODIFY COLUMN `role_type` ENUM(
    'SALES_STAFF',
    'STORE_MANAGER',
    'STORE_SUPERVISOR',
    'DEPUTY_MANAGER',
    'CASHIER',
    'WAREHOUSE_STAFF',
    'PURCHASER',
    'CUSTOMER_SERVICE'
  ) NOT NULL;

ALTER TABLE `org_position`
  MODIFY COLUMN `role_type` ENUM(
    'SALES_STAFF',
    'STORE_MANAGER',
    'STORE_SUPERVISOR',
    'DEPUTY_MANAGER',
    'CASHIER',
    'WAREHOUSE_STAFF',
    'PURCHASER',
    'CUSTOMER_SERVICE'
  ) NOT NULL;
