-- Normalize purchase domain tables and inventory movements
-- This migration is idempotent for environments that may already have partial changes.

CREATE TABLE IF NOT EXISTS `purchase_payment` (
  `id` VARCHAR(191) NOT NULL,
  `purchase_order_id` VARCHAR(191) NOT NULL,
  `supplier_id` VARCHAR(191) NOT NULL,
  `cash_amount` DECIMAL(18,2) NOT NULL,
  `discount_amount` DECIMAL(18,2) NOT NULL DEFAULT 0,
  `settled_amount` DECIMAL(18,2) NOT NULL,
  `note` TEXT NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `purchase_payment_purchase_order_id_created_at_idx` (`purchase_order_id`, `created_at`),
  INDEX `purchase_payment_supplier_id_created_at_idx` (`supplier_id`, `created_at`),
  CONSTRAINT `purchase_payment_purchase_order_id_fkey`
    FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_order`(`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `purchase_payment_supplier_id_fkey`
    FOREIGN KEY (`supplier_id`) REFERENCES `partner`(`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `purchase_expense` (
  `id` VARCHAR(191) NOT NULL,
  `purchase_order_id` VARCHAR(191) NOT NULL,
  `supplier_id` VARCHAR(191) NOT NULL,
  `kind` ENUM('TRANSPORT', 'HANDLING', 'OTHER') NOT NULL,
  `label` VARCHAR(191) NOT NULL,
  `amount` DECIMAL(18,2) NOT NULL,
  `note` TEXT NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `purchase_expense_purchase_order_id_created_at_idx` (`purchase_order_id`, `created_at`),
  INDEX `purchase_expense_supplier_id_created_at_idx` (`supplier_id`, `created_at`),
  CONSTRAINT `purchase_expense_purchase_order_id_fkey`
    FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_order`(`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `purchase_expense_supplier_id_fkey`
    FOREIGN KEY (`supplier_id`) REFERENCES `partner`(`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `purchase_rebate` (
  `id` VARCHAR(191) NOT NULL,
  `purchase_order_id` VARCHAR(191) NOT NULL,
  `supplier_id` VARCHAR(191) NOT NULL,
  `label` VARCHAR(191) NOT NULL,
  `amount` DECIMAL(18,2) NOT NULL,
  `note` TEXT NULL,
  `purchased_qty` INT NOT NULL DEFAULT 0,
  `sold_qty` INT NOT NULL DEFAULT 0,
  `sold_ratio` DECIMAL(9,6) NOT NULL DEFAULT 0,
  `cogs_adjustment_amount` DECIMAL(18,2) NOT NULL DEFAULT 0,
  `inventory_adjustment_amount` DECIMAL(18,2) NOT NULL DEFAULT 0,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `purchase_rebate_purchase_order_id_created_at_idx` (`purchase_order_id`, `created_at`),
  INDEX `purchase_rebate_supplier_id_created_at_idx` (`supplier_id`, `created_at`),
  CONSTRAINT `purchase_rebate_purchase_order_id_fkey`
    FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_order`(`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `purchase_rebate_supplier_id_fkey`
    FOREIGN KEY (`supplier_id`) REFERENCES `partner`(`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `inventory_movement` (
  `id` VARCHAR(191) NOT NULL,
  `product_id` VARCHAR(191) NOT NULL,
  `store_id` VARCHAR(191) NOT NULL,
  `movement_type` ENUM('PURCHASE_RECEIPT', 'PURCHASE_VOID', 'ADJUSTMENT') NOT NULL,
  `quantity_delta` INT NOT NULL,
  `unit_cost` DECIMAL(18,2) NULL,
  `total_cost` DECIMAL(18,2) NULL,
  `reference_type` VARCHAR(191) NOT NULL,
  `reference_id` VARCHAR(191) NOT NULL,
  `note` TEXT NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  INDEX `inventory_movement_product_id_store_id_created_at_idx` (`product_id`, `store_id`, `created_at`),
  INDEX `inventory_movement_reference_type_reference_id_idx` (`reference_type`, `reference_id`),
  CONSTRAINT `inventory_movement_product_id_fkey`
    FOREIGN KEY (`product_id`) REFERENCES `product`(`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `inventory_movement_store_id_fkey`
    FOREIGN KEY (`store_id`) REFERENCES `store`(`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

SET @add_line_discount_sql = (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = DATABASE()
        AND table_name = 'purchase_order_item'
        AND column_name = 'line_discount'
    ),
    'SELECT 1',
    'ALTER TABLE `purchase_order_item` ADD COLUMN `line_discount` DECIMAL(18,2) NOT NULL DEFAULT 0 AFTER `unit_cost`'
  )
);
PREPARE stmt FROM @add_line_discount_sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @idx_ptl_type_ref_partner_sql = (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.statistics
      WHERE table_schema = DATABASE()
        AND table_name = 'partner_transaction_log'
        AND index_name = 'partner_transaction_log_transaction_type_reference_id_partner_id_idx'
    ),
    'SELECT 1',
    'CREATE INDEX `partner_transaction_log_transaction_type_reference_id_partner_id_idx` ON `partner_transaction_log`(`transaction_type`, `reference_id`, `partner_id`)'
  )
);
PREPARE stmt FROM @idx_ptl_type_ref_partner_sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @idx_ptl_partner_type_created_sql = (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.statistics
      WHERE table_schema = DATABASE()
        AND table_name = 'partner_transaction_log'
        AND index_name = 'partner_transaction_log_partner_id_transaction_type_created_at_idx'
    ),
    'SELECT 1',
    'CREATE INDEX `partner_transaction_log_partner_id_transaction_type_created_at_idx` ON `partner_transaction_log`(`partner_id`, `transaction_type`, `created_at`)'
  )
);
PREPARE stmt FROM @idx_ptl_partner_type_created_sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
