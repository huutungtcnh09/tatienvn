ALTER TABLE product
  ADD COLUMN supplier_quoted_price DECIMAL(18,2) NULL,
  ADD COLUMN supplier_quote_note TEXT NULL;
