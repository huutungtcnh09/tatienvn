-- Remove PAYMENT_DISCOUNT from SupplierRebateKind enum
-- Table is empty so this is safe to execute directly
ALTER TABLE `supplier_rebate_adjustment`
  MODIFY COLUMN `kind` ENUM('TRADE_REBATE') NOT NULL DEFAULT 'TRADE_REBATE';
