-- Expand org assignment role enum to include sales person
ALTER TABLE `org_assignment_history`
  MODIFY COLUMN `role_type` ENUM('SALES_PERSON', 'STORE_MANAGER', 'STORE_SUPERVISOR') NOT NULL;

-- Add position master table
CREATE TABLE `org_position` (
  `id` VARCHAR(191) NOT NULL,
  `code` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `role_type` ENUM('SALES_PERSON', 'STORE_MANAGER', 'STORE_SUPERVISOR') NOT NULL,
  `scope_type` ENUM('STORE') NOT NULL DEFAULT 'STORE',
  `store_id` VARCHAR(191) NULL,
  `is_active` BOOLEAN NOT NULL DEFAULT true,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` DATETIME(3) NOT NULL,
  UNIQUE INDEX `org_position_code_key`(`code`),
  INDEX `org_position_store_id_role_type_is_active_idx`(`store_id`, `role_type`, `is_active`),
  PRIMARY KEY (`id`),
  CONSTRAINT `org_position_store_id_fkey` FOREIGN KEY (`store_id`) REFERENCES `store`(`id`) ON DELETE SET NULL ON UPDATE CASCADE
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Add position assignment history
CREATE TABLE `org_position_assignment_history` (
  `id` VARCHAR(191) NOT NULL,
  `position_id` VARCHAR(191) NOT NULL,
  `user_id` VARCHAR(191) NOT NULL,
  `effective_from` DATETIME(3) NOT NULL,
  `effective_to` DATETIME(3) NULL,
  `decision_no` VARCHAR(191) NULL,
  `note` TEXT NULL,
  `created_by` VARCHAR(191) NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` DATETIME(3) NOT NULL,
  INDEX `org_position_assignment_history_position_id_effective_from_idx`(`position_id`, `effective_from`),
  INDEX `org_position_assignment_history_user_id_effective_from_idx`(`user_id`, `effective_from`),
  PRIMARY KEY (`id`),
  CONSTRAINT `org_position_assignment_history_position_id_fkey` FOREIGN KEY (`position_id`) REFERENCES `org_position`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `org_position_assignment_history_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Partner owner by position
ALTER TABLE `partner`
  ADD COLUMN `account_owner_position_id` VARCHAR(191) NULL,
  ADD INDEX `partner_account_owner_position_id_idx`(`account_owner_position_id`),
  ADD CONSTRAINT `partner_account_owner_position_id_fkey`
    FOREIGN KEY (`account_owner_position_id`) REFERENCES `org_position`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- Order snapshot by position
ALTER TABLE `sales_order`
  ADD COLUMN `sales_owner_position_id` VARCHAR(191) NULL,
  ADD COLUMN `store_manager_position_id` VARCHAR(191) NULL,
  ADD COLUMN `store_supervisor_position_id` VARCHAR(191) NULL,
  ADD INDEX `sales_order_sales_owner_position_id_idx`(`sales_owner_position_id`),
  ADD INDEX `sales_order_store_manager_position_id_idx`(`store_manager_position_id`),
  ADD INDEX `sales_order_store_supervisor_position_id_idx`(`store_supervisor_position_id`),
  ADD CONSTRAINT `sales_order_sales_owner_position_id_fkey`
    FOREIGN KEY (`sales_owner_position_id`) REFERENCES `org_position`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `sales_order_store_manager_position_id_fkey`
    FOREIGN KEY (`store_manager_position_id`) REFERENCES `org_position`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `sales_order_store_supervisor_position_id_fkey`
    FOREIGN KEY (`store_supervisor_position_id`) REFERENCES `org_position`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
