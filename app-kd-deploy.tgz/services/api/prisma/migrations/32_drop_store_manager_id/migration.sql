-- Drop legacy manager_id from store after migrating to position/assignment model.
SET @fk_name := (
  SELECT kcu.CONSTRAINT_NAME
  FROM information_schema.KEY_COLUMN_USAGE kcu
  WHERE kcu.TABLE_SCHEMA = DATABASE()
    AND kcu.TABLE_NAME = 'store'
    AND kcu.COLUMN_NAME = 'manager_id'
    AND kcu.REFERENCED_TABLE_NAME IS NOT NULL
  LIMIT 1
);

SET @drop_fk_sql := IF(
  @fk_name IS NOT NULL,
  CONCAT('ALTER TABLE `store` DROP FOREIGN KEY `', @fk_name, '`'),
  'SELECT 1'
);
PREPARE stmt_drop_fk FROM @drop_fk_sql;
EXECUTE stmt_drop_fk;
DEALLOCATE PREPARE stmt_drop_fk;

SET @has_manager_col := (
  SELECT COUNT(*)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'store'
    AND COLUMN_NAME = 'manager_id'
);

SET @drop_col_sql := IF(
  @has_manager_col > 0,
  'ALTER TABLE `store` DROP COLUMN `manager_id`',
  'SELECT 1'
);
PREPARE stmt_drop_col FROM @drop_col_sql;
EXECUTE stmt_drop_col;
DEALLOCATE PREPARE stmt_drop_col;
