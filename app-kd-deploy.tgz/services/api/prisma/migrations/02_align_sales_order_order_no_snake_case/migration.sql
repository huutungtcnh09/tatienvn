-- Ensure SalesOrder number column follows snake_case naming in existing databases.
-- This migration is idempotent: it only renames the column when the old camelCase name exists.

SET @has_old_column := (
  SELECT COUNT(*)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'sales_order'
    AND COLUMN_NAME = 'orderNo'
);

SET @rename_sql := IF(
  @has_old_column > 0,
  'ALTER TABLE `sales_order` CHANGE COLUMN `orderNo` `order_no` VARCHAR(191) NOT NULL;',
  'SELECT 1;'
);

PREPARE stmt FROM @rename_sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
