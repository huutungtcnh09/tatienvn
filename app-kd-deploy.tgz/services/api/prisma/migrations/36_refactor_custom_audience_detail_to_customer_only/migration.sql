-- Refactor custom audience detail to store customer reference only.
-- This migration is idempotent to recover from partial runs on MySQL.

-- 1) Remove rows not linked to a valid customer
DELETE d
FROM `marketing_custom_audience_detail` d
LEFT JOIN `partner` p
  ON p.`id` = d.`customer_id`
  AND p.`is_customer` = TRUE
WHERE d.`customer_id` IS NULL
   OR p.`id` IS NULL;

-- 2) Deduplicate by (custom_audience_id, customer_id)
DELETE d1
FROM `marketing_custom_audience_detail` d1
INNER JOIN `marketing_custom_audience_detail` d2
  ON d1.`custom_audience_id` = d2.`custom_audience_id`
 AND d1.`customer_id` = d2.`customer_id`
 AND d1.`id` > d2.`id`;

-- 3) Drop customer FK first (old FK can be ON DELETE SET NULL)
SET @has_fk_mcad_customer := (
  SELECT COUNT(*)
  FROM information_schema.REFERENTIAL_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = DATABASE()
    AND TABLE_NAME = 'marketing_custom_audience_detail'
    AND CONSTRAINT_NAME = 'marketing_custom_audience_detail_customer_id_fkey'
);

SET @drop_fk_mcad_customer_sql := IF(
  @has_fk_mcad_customer = 1,
  'ALTER TABLE `marketing_custom_audience_detail` DROP FOREIGN KEY `marketing_custom_audience_detail_customer_id_fkey`',
  'SELECT 1'
);
PREPARE stmt_drop_fk_mcad_customer FROM @drop_fk_mcad_customer_sql;
EXECUTE stmt_drop_fk_mcad_customer;
DEALLOCATE PREPARE stmt_drop_fk_mcad_customer;

-- 4) Drop obsolete snapshot contact columns if they still exist
SET @has_email := (
  SELECT COUNT(*)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'marketing_custom_audience_detail'
    AND COLUMN_NAME = 'email'
);
SET @drop_email_sql := IF(
  @has_email = 1,
  'ALTER TABLE `marketing_custom_audience_detail` DROP COLUMN `email`',
  'SELECT 1'
);
PREPARE stmt_drop_email FROM @drop_email_sql;
EXECUTE stmt_drop_email;
DEALLOCATE PREPARE stmt_drop_email;

SET @has_phone_1 := (
  SELECT COUNT(*)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'marketing_custom_audience_detail'
    AND COLUMN_NAME = 'phone_1'
);
SET @drop_phone_1_sql := IF(
  @has_phone_1 = 1,
  'ALTER TABLE `marketing_custom_audience_detail` DROP COLUMN `phone_1`',
  'SELECT 1'
);
PREPARE stmt_drop_phone_1 FROM @drop_phone_1_sql;
EXECUTE stmt_drop_phone_1;
DEALLOCATE PREPARE stmt_drop_phone_1;

SET @has_phone_2 := (
  SELECT COUNT(*)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'marketing_custom_audience_detail'
    AND COLUMN_NAME = 'phone_2'
);
SET @drop_phone_2_sql := IF(
  @has_phone_2 = 1,
  'ALTER TABLE `marketing_custom_audience_detail` DROP COLUMN `phone_2`',
  'SELECT 1'
);
PREPARE stmt_drop_phone_2 FROM @drop_phone_2_sql;
EXECUTE stmt_drop_phone_2;
DEALLOCATE PREPARE stmt_drop_phone_2;

SET @has_phone_3 := (
  SELECT COUNT(*)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'marketing_custom_audience_detail'
    AND COLUMN_NAME = 'phone_3'
);
SET @drop_phone_3_sql := IF(
  @has_phone_3 = 1,
  'ALTER TABLE `marketing_custom_audience_detail` DROP COLUMN `phone_3`',
  'SELECT 1'
);
PREPARE stmt_drop_phone_3 FROM @drop_phone_3_sql;
EXECUTE stmt_drop_phone_3;
DEALLOCATE PREPARE stmt_drop_phone_3;

-- 5) Enforce non-null customer_id
SET @is_customer_nullable := (
  SELECT CASE WHEN IS_NULLABLE = 'YES' THEN 1 ELSE 0 END
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'marketing_custom_audience_detail'
    AND COLUMN_NAME = 'customer_id'
);
SET @set_customer_not_null_sql := IF(
  @is_customer_nullable = 1,
  'ALTER TABLE `marketing_custom_audience_detail` MODIFY `customer_id` VARCHAR(191) NOT NULL',
  'SELECT 1'
);
PREPARE stmt_set_customer_not_null FROM @set_customer_not_null_sql;
EXECUTE stmt_set_customer_not_null;
DEALLOCATE PREPARE stmt_set_customer_not_null;

-- 6) Re-create customer FK with RESTRICT semantics
SET @has_fk_mcad_customer_after := (
  SELECT COUNT(*)
  FROM information_schema.REFERENTIAL_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = DATABASE()
    AND TABLE_NAME = 'marketing_custom_audience_detail'
    AND CONSTRAINT_NAME = 'marketing_custom_audience_detail_customer_id_fkey'
);
SET @add_fk_mcad_customer_sql := IF(
  @has_fk_mcad_customer_after = 0,
  'ALTER TABLE `marketing_custom_audience_detail` ADD CONSTRAINT `marketing_custom_audience_detail_customer_id_fkey` FOREIGN KEY (`customer_id`) REFERENCES `partner`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE',
  'SELECT 1'
);
PREPARE stmt_add_fk_mcad_customer FROM @add_fk_mcad_customer_sql;
EXECUTE stmt_add_fk_mcad_customer;
DEALLOCATE PREPARE stmt_add_fk_mcad_customer;

-- 7) Prevent duplicate customer rows in the same audience
SET @has_unique_customer_per_audience := (
  SELECT COUNT(*)
  FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'marketing_custom_audience_detail'
    AND INDEX_NAME = 'mca_detail_audience_customer_uk'
);
SET @add_unique_customer_per_audience_sql := IF(
  @has_unique_customer_per_audience = 0,
  'CREATE UNIQUE INDEX `mca_detail_audience_customer_uk` ON `marketing_custom_audience_detail`(`custom_audience_id`, `customer_id`)',
  'SELECT 1'
);
PREPARE stmt_add_unique_customer_per_audience FROM @add_unique_customer_per_audience_sql;
EXECUTE stmt_add_unique_customer_per_audience;
DEALLOCATE PREPARE stmt_add_unique_customer_per_audience;
