-- Create purchase_rebate_allocation table
CREATE TABLE purchase_rebate_allocation (
  id VARCHAR(191) NOT NULL PRIMARY KEY,
  purchase_rebate_id VARCHAR(191) NOT NULL,
  purchase_order_id VARCHAR(191) NOT NULL,
  allocated_amount DECIMAL(18, 2) NOT NULL,
  allocation_date DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  status VARCHAR(191) NOT NULL DEFAULT 'CONFIRMED',
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  
  UNIQUE KEY `purchase_rebate_allocation_purchase_rebate_id_purchase_order_id_key` (purchase_rebate_id, purchase_order_id),
  KEY `purchase_rebate_allocation_purchase_rebate_id_idx` (purchase_rebate_id),
  KEY `purchase_rebate_allocation_purchase_order_id_idx` (purchase_order_id),
  
  CONSTRAINT `purchase_rebate_allocation_purchase_rebate_id_fkey` FOREIGN KEY (purchase_rebate_id) REFERENCES purchase_rebate(id) ON DELETE CASCADE,
  CONSTRAINT `purchase_rebate_allocation_purchase_order_id_fkey` FOREIGN KEY (purchase_order_id) REFERENCES purchase_order(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
