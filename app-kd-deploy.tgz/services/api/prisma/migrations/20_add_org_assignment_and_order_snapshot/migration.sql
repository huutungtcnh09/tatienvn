-- Add temporal organization assignment table
CREATE TABLE `org_assignment_history` (
  `id` VARCHAR(191) NOT NULL,
  `user_id` VARCHAR(191) NOT NULL,
  `role_type` ENUM('STORE_MANAGER', 'STORE_SUPERVISOR') NOT NULL,
  `scope_type` ENUM('STORE') NOT NULL DEFAULT 'STORE',
  `store_id` VARCHAR(191) NULL,
  `effective_from` DATETIME(3) NOT NULL,
  `effective_to` DATETIME(3) NULL,
  `decision_no` VARCHAR(191) NULL,
  `note` TEXT NULL,
  `created_by` VARCHAR(191) NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `org_assignment_history_user_id_role_type_effective_from_idx`(`user_id`, `role_type`, `effective_from`),
  INDEX `org_assignment_history_store_id_role_type_effective_from_idx`(`store_id`, `role_type`, `effective_from`),
  CONSTRAINT `org_assignment_history_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `org_assignment_history_store_id_fkey` FOREIGN KEY (`store_id`) REFERENCES `store`(`id`) ON DELETE SET NULL ON UPDATE CASCADE
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Add snapshot columns on sales_order
ALTER TABLE `sales_order`
  ADD COLUMN `sales_person_id` VARCHAR(191) NULL,
  ADD COLUMN `store_manager_id` VARCHAR(191) NULL,
  ADD COLUMN `store_supervisor_id` VARCHAR(191) NULL,
  ADD COLUMN `org_snapshot_at` DATETIME(3) NULL;

ALTER TABLE `sales_order`
  ADD INDEX `sales_order_sales_person_id_idx`(`sales_person_id`),
  ADD INDEX `sales_order_store_manager_id_idx`(`store_manager_id`),
  ADD INDEX `sales_order_store_supervisor_id_idx`(`store_supervisor_id`);

ALTER TABLE `sales_order`
  ADD CONSTRAINT `sales_order_sales_person_id_fkey` FOREIGN KEY (`sales_person_id`) REFERENCES `user`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `sales_order_store_manager_id_fkey` FOREIGN KEY (`store_manager_id`) REFERENCES `user`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `sales_order_store_supervisor_id_fkey` FOREIGN KEY (`store_supervisor_id`) REFERENCES `user`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
