ALTER TABLE `product`
  ADD COLUMN `is_tracked_in_overview` TINYINT(1) NOT NULL DEFAULT 1;
