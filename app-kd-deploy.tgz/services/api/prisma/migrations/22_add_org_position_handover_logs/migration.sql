CREATE TABLE `org_position_handover_log` (
  `id` VARCHAR(191) NOT NULL,
  `partner_id` VARCHAR(191) NOT NULL,
  `position_id` VARCHAR(191) NOT NULL,
  `from_user_id` VARCHAR(191) NOT NULL,
  `to_user_id` VARCHAR(191) NOT NULL,
  `reason` TEXT NULL,
  `created_by` VARCHAR(191) NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  INDEX `org_position_handover_log_from_user_id_created_at_idx`(`from_user_id`, `created_at`),
  INDEX `org_position_handover_log_to_user_id_created_at_idx`(`to_user_id`, `created_at`),
  INDEX `org_position_handover_log_position_id_created_at_idx`(`position_id`, `created_at`),
  INDEX `org_position_handover_log_partner_id_created_at_idx`(`partner_id`, `created_at`),
  PRIMARY KEY (`id`),
  CONSTRAINT `org_position_handover_log_partner_id_fkey` FOREIGN KEY (`partner_id`) REFERENCES `partner`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `org_position_handover_log_position_id_fkey` FOREIGN KEY (`position_id`) REFERENCES `org_position`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `org_position_handover_log_from_user_id_fkey` FOREIGN KEY (`from_user_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `org_position_handover_log_to_user_id_fkey` FOREIGN KEY (`to_user_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
