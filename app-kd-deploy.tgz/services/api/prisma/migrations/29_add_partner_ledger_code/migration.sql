ALTER TABLE `partner`
  ADD COLUMN `ledger_code` VARCHAR(64) NULL;
