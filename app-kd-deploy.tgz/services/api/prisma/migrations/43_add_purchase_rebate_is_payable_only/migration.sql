ALTER TABLE purchase_rebate
  ADD COLUMN is_payable_only TINYINT(1) NOT NULL DEFAULT 0 AFTER rebate_batch_id;

-- Backfill old payable-only direct rebates that were encoded in note text.
UPDATE purchase_rebate
SET is_payable_only = 1
WHERE rebate_batch_id IS NULL
  AND note IS NOT NULL
  AND note LIKE '%[REBATE_BATCH_REF:%';

CREATE INDEX purchase_rebate_is_payable_only_idx ON purchase_rebate(is_payable_only);
