ALTER TABLE purchase_expense
  ADD COLUMN is_paid TINYINT(1) NOT NULL DEFAULT 0 AFTER amount,
  ADD COLUMN settled_amount DECIMAL(18,2) NOT NULL DEFAULT 0 AFTER is_paid;

UPDATE purchase_expense
SET is_paid = 0,
    settled_amount = 0
WHERE is_paid IS NULL OR settled_amount IS NULL;
