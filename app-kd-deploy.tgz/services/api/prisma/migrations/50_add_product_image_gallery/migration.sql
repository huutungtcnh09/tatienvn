ALTER TABLE `product`
  ADD COLUMN `image_gallery` JSON NULL AFTER `image_url`;
