CREATE TABLE `purchase_order` (
  `id` VARCHAR(191) NOT NULL,
  `reference_id` VARCHAR(191) NOT NULL,
  `supplier_id` VARCHAR(191) NOT NULL,
  `store_id` VARCHAR(191) NULL,
  `invoice_no` VARCHAR(191) NULL,
  `document_date` DATE NULL,
  `amount` DECIMAL(18,2) NOT NULL,
  `paid_amount` DECIMAL(18,2) NOT NULL DEFAULT 0,
  `purchase_discount` DECIMAL(18,2) NOT NULL DEFAULT 0,
  `landed_cost` DECIMAL(18,2) NOT NULL DEFAULT 0,
  `note` TEXT NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` DATETIME(3) NOT NULL,

  UNIQUE INDEX `purchase_order_reference_id_key`(`reference_id`),
  INDEX `purchase_order_supplier_id_created_at_idx`(`supplier_id`, `created_at`),
  INDEX `purchase_order_store_id_created_at_idx`(`store_id`, `created_at`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE `purchase_order_item` (
  `id` VARCHAR(191) NOT NULL,
  `purchase_order_id` VARCHAR(191) NOT NULL,
  `product_id` VARCHAR(191) NOT NULL,
  `quantity` INTEGER NOT NULL,
  `unit_cost` DECIMAL(18,2) NOT NULL,
  `line_amount` DECIMAL(18,2) NOT NULL,
  `allocated_doc_discount` DECIMAL(18,2) NOT NULL DEFAULT 0,
  `allocated_landed_cost` DECIMAL(18,2) NOT NULL DEFAULT 0,
  `net_amount` DECIMAL(18,2) NOT NULL,
  `unit_net_cost` DECIMAL(18,2) NOT NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  INDEX `purchase_order_item_purchase_order_id_idx`(`purchase_order_id`),
  INDEX `purchase_order_item_product_id_idx`(`product_id`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `purchase_order`
  ADD CONSTRAINT `purchase_order_supplier_id_fkey`
    FOREIGN KEY (`supplier_id`) REFERENCES `partner`(`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `purchase_order_store_id_fkey`
    FOREIGN KEY (`store_id`) REFERENCES `store`(`id`)
    ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `purchase_order_item`
  ADD CONSTRAINT `purchase_order_item_purchase_order_id_fkey`
    FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_order`(`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `purchase_order_item_product_id_fkey`
    FOREIGN KEY (`product_id`) REFERENCES `product`(`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

INSERT INTO `purchase_order` (
  `id`,
  `reference_id`,
  `supplier_id`,
  `amount`,
  `paid_amount`,
  `purchase_discount`,
  `landed_cost`,
  `note`,
  `created_at`,
  `updated_at`
)
SELECT
  purchase_log.`id`,
  purchase_log.`reference_id`,
  purchase_log.`partner_id`,
  purchase_log.`amount`,
  COALESCE((
    SELECT SUM(payment_log.`amount`)
    FROM `partner_transaction_log` AS payment_log
    WHERE payment_log.`transaction_type` = 'PAYMENT_TO_SUPPLIER'
      AND payment_log.`reference_id` = purchase_log.`reference_id`
      AND payment_log.`partner_id` = purchase_log.`partner_id`
  ), 0) AS `paid_amount`,
  0 AS `purchase_discount`,
  0 AS `landed_cost`,
  purchase_log.`note`,
  purchase_log.`created_at`,
  purchase_log.`created_at`
FROM `partner_transaction_log` AS purchase_log
WHERE purchase_log.`transaction_type` = 'PURCHASE_ORDER';
