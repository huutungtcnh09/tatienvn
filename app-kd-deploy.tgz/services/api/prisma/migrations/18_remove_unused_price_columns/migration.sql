-- Remove unused price columns from product table
ALTER TABLE `product`
  DROP COLUMN `min_price`,
  DROP COLUMN `max_price`,
  DROP COLUMN `special_price`;
