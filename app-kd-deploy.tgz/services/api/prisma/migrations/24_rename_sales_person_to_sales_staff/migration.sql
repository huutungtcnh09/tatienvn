-- Migration 24: Rename SALES_PERSON → SALES_STAFF in OrgRoleType enum
-- Step 1: Expand enum to include both values temporarily
ALTER TABLE `org_assignment_history`
  MODIFY COLUMN `role_type` ENUM('SALES_PERSON','SALES_STAFF','STORE_MANAGER','STORE_SUPERVISOR') NOT NULL;

ALTER TABLE `org_position`
  MODIFY COLUMN `role_type` ENUM('SALES_PERSON','SALES_STAFF','STORE_MANAGER','STORE_SUPERVISOR') NOT NULL;

-- Step 2: Migrate existing data
UPDATE `org_assignment_history` SET `role_type` = 'SALES_STAFF' WHERE `role_type` = 'SALES_PERSON';
UPDATE `org_position` SET `role_type` = 'SALES_STAFF' WHERE `role_type` = 'SALES_PERSON';

-- Step 3: Remove old value from enum
ALTER TABLE `org_assignment_history`
  MODIFY COLUMN `role_type` ENUM('SALES_STAFF','STORE_MANAGER','STORE_SUPERVISOR') NOT NULL;

ALTER TABLE `org_position`
  MODIFY COLUMN `role_type` ENUM('SALES_STAFF','STORE_MANAGER','STORE_SUPERVISOR') NOT NULL;
