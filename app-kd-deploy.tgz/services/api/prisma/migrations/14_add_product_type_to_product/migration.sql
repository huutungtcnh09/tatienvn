ALTER TABLE product
  ADD COLUMN product_type VARCHAR(20) NOT NULL DEFAULT 'GOODS' AFTER name;

UPDATE product
SET product_type = 'GOODS'
WHERE product_type IS NULL OR product_type = '';
