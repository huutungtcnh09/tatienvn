CREATE TABLE `gift_redemption` (
  `id` VARCHAR(191) NOT NULL,
  `partner_id` VARCHAR(191) NOT NULL,
  `product_id` VARCHAR(191) NOT NULL,
  `store_id` VARCHAR(191) NULL,
  `quantity` INTEGER NOT NULL DEFAULT 1,
  `points_cost` INTEGER NOT NULL,
  `note` TEXT NULL,
  `created_by` VARCHAR(191) NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  INDEX `gift_redemption_partner_id_idx`(`partner_id`),
  INDEX `gift_redemption_created_at_idx`(`created_at`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `gift_redemption` ADD CONSTRAINT `gift_redemption_partner_id_fkey`
  FOREIGN KEY (`partner_id`) REFERENCES `partner`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE `gift_redemption` ADD CONSTRAINT `gift_redemption_product_id_fkey`
  FOREIGN KEY (`product_id`) REFERENCES `product`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
