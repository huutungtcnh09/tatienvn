ALTER TABLE `sales_order`
  ADD COLUMN `due_date` DATETIME(3) NULL AFTER `debt_amount`;

CREATE INDEX `sales_order_due_date_idx` ON `sales_order`(`due_date`);
