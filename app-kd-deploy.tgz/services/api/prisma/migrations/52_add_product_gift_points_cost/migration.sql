ALTER TABLE `product` ADD COLUMN `gift_points_cost` INT NOT NULL DEFAULT 0 AFTER `reward_points`;
