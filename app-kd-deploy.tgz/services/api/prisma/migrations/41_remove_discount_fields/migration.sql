ALTER TABLE purchase_order DROP COLUMN IF EXISTS purchase_discount;
ALTER TABLE purchase_order_item DROP COLUMN IF EXISTS line_discount;
ALTER TABLE purchase_order_item DROP COLUMN IF EXISTS allocated_doc_discount;
ALTER TABLE purchase_payment DROP COLUMN IF EXISTS discount_amount;
