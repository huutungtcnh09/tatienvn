ALTER TABLE `product`
  ADD COLUMN `is_visible_on_corporate` TINYINT(1) NOT NULL DEFAULT 0;
