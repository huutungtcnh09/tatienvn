ALTER TABLE `sales_order_item`
  ADD COLUMN `unit_cost` DECIMAL(18,2) NOT NULL DEFAULT 0 AFTER `unit_price`;

UPDATE `sales_order_item` soi
JOIN `product` p ON p.`id` = soi.`product_id`
SET soi.`unit_cost` = p.`cost_price`
WHERE soi.`unit_cost` = 0;
