-- CreateTable "user"
CREATE TABLE `user` (
    `id` VARCHAR(191) NOT NULL,
    `email` VARCHAR(191) NOT NULL,
    `password_hash` VARCHAR(191) NOT NULL,
    `full_name` VARCHAR(191) NOT NULL,
    `is_active` BOOLEAN NOT NULL DEFAULT true,
    `roles` VARCHAR(191) NOT NULL DEFAULT 'STORE_MANAGER',
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL,

    UNIQUE INDEX `user_email_key`(`email`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable "store"
CREATE TABLE `store` (
    `id` VARCHAR(191) NOT NULL,
    `code` VARCHAR(191) NOT NULL,
    `name` VARCHAR(191) NOT NULL,
    `is_warehouse` BOOLEAN NOT NULL DEFAULT false,
    `manager_id` VARCHAR(191),
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `store_code_key`(`code`),
    INDEX `store_manager_id_idx`(`manager_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable "category"
CREATE TABLE `category` (
    `id` VARCHAR(191) NOT NULL,
    `name` VARCHAR(191) NOT NULL,
    `parent_id` VARCHAR(191),
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `category_parent_id_idx`(`parent_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable "partner"
CREATE TABLE `partner` (
    `id` VARCHAR(191) NOT NULL,
    `code` VARCHAR(191) NOT NULL,
    `name` VARCHAR(191) NOT NULL,
    `phone` VARCHAR(191),
    `email` VARCHAR(191),
    `address` VARCHAR(191),
    `is_customer` BOOLEAN NOT NULL DEFAULT false,
    `is_supplier` BOOLEAN NOT NULL DEFAULT false,
    `is_carrier` BOOLEAN NOT NULL DEFAULT false,
    `assigned_user_id` VARCHAR(191),
    `opening_balance` DECIMAL(18, 2) NOT NULL DEFAULT 0,
    `current_debt` DECIMAL(18, 2) NOT NULL DEFAULT 0,
    `reward_points` INT NOT NULL DEFAULT 0,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL,

    UNIQUE INDEX `partner_code_key`(`code`),
    INDEX `partner_assigned_user_id_idx`(`assigned_user_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable "product"
CREATE TABLE `product` (
    `id` VARCHAR(191) NOT NULL,
    `sku` VARCHAR(191) NOT NULL,
    `name` VARCHAR(191) NOT NULL,
    `category_id` VARCHAR(191) NOT NULL,
    `unit` VARCHAR(191) NOT NULL,
    `min_price` DECIMAL(18, 2) NOT NULL,
    `max_price` DECIMAL(18, 2) NOT NULL,
    `default_price` DECIMAL(18, 2) NOT NULL,
    `special_price` DECIMAL(18, 2),
    `reward_points` INT NOT NULL DEFAULT 0,
    `cost_price` DECIMAL(18, 2) NOT NULL DEFAULT 0,
    `image_url` VARCHAR(191),
    `is_active` BOOLEAN NOT NULL DEFAULT true,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL,

    UNIQUE INDEX `product_sku_key`(`sku`),
    INDEX `product_category_id_idx`(`category_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable "inventory"
CREATE TABLE `inventory` (
    `id` VARCHAR(191) NOT NULL,
    `product_id` VARCHAR(191) NOT NULL,
    `store_id` VARCHAR(191) NOT NULL,
    `quantity` INT NOT NULL DEFAULT 0,
    `reserved_quantity` INT NOT NULL DEFAULT 0,
    `updated_at` DATETIME(3) NOT NULL,

    UNIQUE INDEX `inventory_product_id_store_id_key`(`product_id`, `store_id`),
    INDEX `inventory_store_id_idx`(`store_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable "customer_price_list"
CREATE TABLE `customer_price_list` (
    `id` VARCHAR(191) NOT NULL,
    `customer_id` VARCHAR(191) NOT NULL,
    `product_id` VARCHAR(191) NOT NULL,
    `price` DECIMAL(18, 2) NOT NULL,
    `status` VARCHAR(191) NOT NULL DEFAULT 'active',
    `created_by` VARCHAR(191) NOT NULL,
    `store_id` VARCHAR(191),
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL,

    UNIQUE INDEX `customer_price_list_customer_id_product_id_status_key`(`customer_id`, `product_id`, `status`),
    INDEX `customer_price_list_product_id_idx`(`product_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable "customer_price_list_history"
CREATE TABLE `customer_price_list_history` (
    `id` VARCHAR(191) NOT NULL,
    `price_list_id` VARCHAR(191) NOT NULL,
    `old_price` DECIMAL(18, 2) NOT NULL,
    `new_price` DECIMAL(18, 2) NOT NULL,
    `changed_by` VARCHAR(191) NOT NULL,
    `changed_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `customer_price_list_history_price_list_id_idx`(`price_list_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable "sales_order"
CREATE TABLE `sales_order` (
    `id` VARCHAR(191) NOT NULL,
    `order_no` VARCHAR(191) NOT NULL,
    `store_id` VARCHAR(191) NOT NULL,
    `customer_id` VARCHAR(191) NOT NULL,
    `status` ENUM('DRAFT', 'CONFIRMED', 'PROCESSING', 'DELIVERED', 'COMPLETED', 'CANCELLED', 'RETURNED', 'REFUNDED') NOT NULL DEFAULT 'DRAFT',
    `payment_method` ENUM('CASH', 'BANK_TRANSFER', 'CARD', 'MIXED') NOT NULL,
    `subtotal` DECIMAL(18, 2) NOT NULL DEFAULT 0,
    `discount_amount` DECIMAL(18, 2) NOT NULL DEFAULT 0,
    `total_amount` DECIMAL(18, 2) NOT NULL DEFAULT 0,
    `paid_amount` DECIMAL(18, 2) NOT NULL DEFAULT 0,
    `debt_amount` DECIMAL(18, 2) NOT NULL DEFAULT 0,
    `is_prepaid` BOOLEAN NOT NULL DEFAULT false,
    `is_reserved` BOOLEAN NOT NULL DEFAULT false,
    `note` VARCHAR(191),
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL,

    UNIQUE INDEX `sales_order_order_no_key`(`order_no`),
    INDEX `sales_order_store_id_idx`(`store_id`),
    INDEX `sales_order_customer_id_idx`(`customer_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable "sales_order_item"
CREATE TABLE `sales_order_item` (
    `id` VARCHAR(191) NOT NULL,
    `order_id` VARCHAR(191) NOT NULL,
    `product_id` VARCHAR(191) NOT NULL,
    `quantity` INT NOT NULL,
    `unit_price` DECIMAL(18, 2) NOT NULL,
    `discount_amount` DECIMAL(18, 2) NOT NULL DEFAULT 0,
    `total_amount` DECIMAL(18, 2) NOT NULL,
    `is_gift` BOOLEAN NOT NULL DEFAULT false,

    INDEX `sales_order_item_product_id_idx`(`product_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable "receipt"
CREATE TABLE `receipt` (
    `id` VARCHAR(191) NOT NULL,
    `receipt_no` VARCHAR(191) NOT NULL,
    `customer_id` VARCHAR(191) NOT NULL,
    `store_id` VARCHAR(191) NOT NULL,
    `type` ENUM('PAYMENT', 'DISCOUNT', 'PREPAYMENT') NOT NULL DEFAULT 'PAYMENT',
    `payment_method` ENUM('CASH', 'BANK_TRANSFER', 'CARD', 'MIXED') NOT NULL,
    `amount` DECIMAL(18, 2) NOT NULL,
    `discount_amount` DECIMAL(18, 2) NOT NULL DEFAULT 0,
    `note` VARCHAR(191),
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `receipt_receipt_no_key`(`receipt_no`),
    INDEX `receipt_customer_id_idx`(`customer_id`),
    INDEX `receipt_store_id_idx`(`store_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable "promotion"
CREATE TABLE `promotion` (
    `id` VARCHAR(191) NOT NULL,
    `name` VARCHAR(191) NOT NULL,
    `type` VARCHAR(191) NOT NULL,
    `trigger_product_id` VARCHAR(191) NOT NULL,
    `trigger_qty` INT NOT NULL,
    `reward_product_id` VARCHAR(191),
    `reward_qty` INT,
    `start_date` DATETIME(3) NOT NULL,
    `end_date` DATETIME(3) NOT NULL,
    `is_active` BOOLEAN NOT NULL DEFAULT true,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable "partner_transaction_log"
CREATE TABLE `partner_transaction_log` (
    `id` VARCHAR(191) NOT NULL,
    `partner_id` VARCHAR(191) NOT NULL,
    `transaction_type` ENUM('SALE_ORDER', 'PAYMENT_RECEIPT', 'DISCOUNT_VOUCHER', 'RETURN_ORDER', 'PURCHASE_ORDER', 'PAYMENT_TO_SUPPLIER', 'OPENING_BALANCE') NOT NULL,
    `reference_id` VARCHAR(191) NOT NULL,
    `amount` DECIMAL(18, 2) NOT NULL,
    `note` VARCHAR(191),
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `partner_transaction_log_partner_id_idx`(`partner_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `store` ADD CONSTRAINT `store_manager_id_fk` FOREIGN KEY (`manager_id`) REFERENCES `user`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `category` ADD CONSTRAINT `category_parent_id_fk` FOREIGN KEY (`parent_id`) REFERENCES `category`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `partner` ADD CONSTRAINT `partner_assigned_user_id_fk` FOREIGN KEY (`assigned_user_id`) REFERENCES `user`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `product` ADD CONSTRAINT `product_category_id_fk` FOREIGN KEY (`category_id`) REFERENCES `category`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `inventory` ADD CONSTRAINT `inventory_product_id_fk` FOREIGN KEY (`product_id`) REFERENCES `product`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `inventory` ADD CONSTRAINT `inventory_store_id_fk` FOREIGN KEY (`store_id`) REFERENCES `store`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `customer_price_list` ADD CONSTRAINT `customer_price_list_customer_id_fk` FOREIGN KEY (`customer_id`) REFERENCES `partner`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `customer_price_list` ADD CONSTRAINT `customer_price_list_product_id_fk` FOREIGN KEY (`product_id`) REFERENCES `product`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `customer_price_list_history` ADD CONSTRAINT `customer_price_list_history_price_list_id_fk` FOREIGN KEY (`price_list_id`) REFERENCES `customer_price_list`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `sales_order` ADD CONSTRAINT `sales_order_store_id_fk` FOREIGN KEY (`store_id`) REFERENCES `store`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `sales_order` ADD CONSTRAINT `sales_order_customer_id_fk` FOREIGN KEY (`customer_id`) REFERENCES `partner`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `sales_order_item` ADD CONSTRAINT `sales_order_item_order_id_fk` FOREIGN KEY (`order_id`) REFERENCES `sales_order`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `sales_order_item` ADD CONSTRAINT `sales_order_item_product_id_fk` FOREIGN KEY (`product_id`) REFERENCES `product`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `receipt` ADD CONSTRAINT `receipt_customer_id_fk` FOREIGN KEY (`customer_id`) REFERENCES `partner`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `receipt` ADD CONSTRAINT `receipt_store_id_fk` FOREIGN KEY (`store_id`) REFERENCES `store`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `partner_transaction_log` ADD CONSTRAINT `partner_transaction_log_partner_id_fk` FOREIGN KEY (`partner_id`) REFERENCES `partner`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
